?package(logtool):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="logtool" command="/usr/bin/logtool"
