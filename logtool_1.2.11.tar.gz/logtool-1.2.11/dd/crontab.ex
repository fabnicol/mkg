0 4	* * *	root	logtool_maintenance
