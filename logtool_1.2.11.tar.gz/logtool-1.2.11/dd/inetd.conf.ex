#:OTHER:
logtool	stream	tcp	nowait	root	/usr/sbin/tcpd /usr/sbin/logtool
