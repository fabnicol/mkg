#!/bin/sh


for i in *.o ; do
if [ "$i" != "logtool.o" ] ; then
ar rv liblogtool.a $i
#  a - $i
fi
done

