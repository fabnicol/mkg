#include "includes.h"

short int ltm_use_syslog;
short int ltm_use_snort;
short int ltm_use_sudo;

int h_errno;
struct hostent *h;

st_event event;
st_color color;
CONFIG cf;
STRUCTURE_REGEXS reg;

SNORT sn;
IPTABLES it;
