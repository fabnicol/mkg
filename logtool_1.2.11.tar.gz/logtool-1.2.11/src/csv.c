/*
 *   logtool - a logfile parsing/monitoring/manipulation utility
 *
 *   Copyright (C) Y2K (2000) A.L.Lambert
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "includes.h"
void lt_colorset_csv() {

        strncpy(color.red, "\"", 127);
        strncpy(color.brightred, "\"", 127);
	
        strncpy(color.green, "\"", 127);
        strncpy(color.brightgreen, "\"", 127);
        
	strncpy(color.yellow, "\"", 127);
        strncpy(color.brightyellow, "\"", 127);
        
	strncpy(color.dimwhite, "\"", 127);
        strncpy(color.white, "\"", 127);
        strncpy(color.brightwhite, "\"", 127);
        
	strncpy(color.cyan, "\"", 127);
        strncpy(color.brightcyan, "\"", 127);

        strncpy(color.magenta, "\"", 127);
        strncpy(color.brightmagenta, "\"", 127);

	strncpy(color.blue, "\"", 127);
        strncpy(color.brightblue, "\"", 127);
	
	strncpy(color.unknown, "\"", 127);
        strncpy(color.end, "\",", 127);

}

void lto_parse_csv() {
        /* we have to do some additional parsing for CSV's :(	
	 * some variables to facilitate this	*/
	char tmp_str[(LSIZE * 2)];
	char *ptr;

	parse_pmsg();
	
	strcpy(tmp_str, event.pmsg);
	
	ptr = event.pmsg;
	ptr = ptr + 2;
	strcpy(event.pmsg, ptr);
	
	while(strcmp(event.pmsg, tmp_str) != 0) {
		strcpy(event.pmsg, tmp_str);
		lt_strep(tmp_str, sizeof(tmp_str), "\", \"", "\",\"");	
		lt_strep(tmp_str, sizeof(tmp_str), "\",\" ", "\",\"");	
	}
	
	ptr = event.pmsg;
	ptr = ptr + 2;
	strcpy(event.pmsg, ptr);

	ptr = strrchr(event.pmsg, ',');
	ptr = ptr - 2;
	ptr[0] = '\0';
			
	
}

void lto_csv() {

        /* parse the \033e escpae sequences into native ANSI    */
        lto_parse_csv();

        printf("%s\n", event.pmsg);
        fflush(stdout);
}

