/*
 *   logtool - a logfile parsing/monitoring/manipulation utility
 *
 *   Copyright (C) Y2K (2000) A.L.Lambert
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef LOGTOOL_INCLUDES_H
#define LOGTOOL_INCLUDES_H

/* The configure/autoconf generated header file */
#ifdef HAVE_CONFIG_H
#include "../config.h"
#endif

/* Include yee ole standard C function headers */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<regex.h>
#include<errno.h>
#include<time.h>

/* includes for the gethostbyaddr() stuff        */
#include <netdb.h>
#include <sys/socket.h>        /* for AF_INET */
#include <netinet/in.h>
#include <arpa/inet.h>
/* a couple var's for gethostbyaddr() stuff      */
extern int h_errno;
extern struct hostent *h;

/* For stat(), opendir(), and friends */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>

/* in here we work with the event-centric modules	*/
#include "mods.h"	/* declare this before logtool.h */
/* we use some structs from this in logtool.h (yeah, I know, lousy organization :) */

/* The program specific headers */
#include "logtool.h"
#include "config.h"


/* 
 * Note: we include the getopt.h header in this package instead
 * of depending on the system getopt.h, since Solaris doesn't 
 * seem to have one by default.  This sucks, but it's not that
 * big a deal, so we'll do it for portability's sake
 */
#ifdef HAVE_GETOPT_H
#include<getopt.h>
#else
#include "getopt.h"
#endif

#endif
