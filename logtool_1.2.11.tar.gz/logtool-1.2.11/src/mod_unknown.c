/*
 *   logtool - a logfile parsing/monitoring/manipulation utility
 *
 *   Copyright (C) Y2K (2000) A.L.Lambert
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* Yee ole includes (I put this all in one file for my sanity) */
#include "includes.h"

/* there ain't no such thing as this module yet. Bummer, eh?	*/

/*
 * There is no such module as of yet.  It is in the works for version 1.2.0
 * 
 * Try not to look so dissappointed, eh? :P
 * 
 */
 
short int ltm_unknown() { 

	/* Figure out what color (red/green/yellow etc) this message should be */
	lt_set_event_color();
	/* tear off any \n's we might find (our output fuction will add them as needed later	*/
	if(event.raw[strlen(event.raw) - 1] == '\n') {
		event.raw[strlen(event.raw) - 1] = '\0';
	}
	/* setup event.pmsg based on what we know now about the color	*/
	sprintf(event.pmsg, "%s%s%s", event.pcolor, event.raw, "\033e");	
	return 0;	/* and that's that :)	*/
}
