#!/bin/sh

mailto="me@mydomain.com"
reportname="My Report"
logfiles="/var/log/messages /var/log/secure"

cat $logfiles | logtool | mail -s "$reportname" $mailto

