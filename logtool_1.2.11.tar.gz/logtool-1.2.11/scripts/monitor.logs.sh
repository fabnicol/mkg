#!/bin/sh


logfiles="/var/log/messages /var/log/secure"

tail -f logfiles | logtool

