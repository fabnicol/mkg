#!/bin/sh

# Season these variables to suit
logfiles="/var/log/messages /var/log/secure"
outputfile="/home/httpd/html/logs/index.html"


cat $logfiles | logtool > $outputfile

